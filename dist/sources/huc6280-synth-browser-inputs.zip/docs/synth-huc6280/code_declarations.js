// SPDX-License-Identifier: BSD-3-Clause
import {selectCodeHostDeclarations} from '../synth/synth_code_declarations.js';
export const HUC6280_CODE_GLOBALS=Object.freeze([
  'context','fx','CH1','CH2','CH3','CH4','CH5','CH6','console','log','useSoundChip','file','setBpm','beat','nextBeat','sleep','sleepSamples','tween',
  'liveLoop','livePrepare','liveFx','stopLoop','stopAllLoops','liveCleanup','trackAsync','parseNoteName','midiToNoteName',
  'scale','chord','lerp','choose','cycle','rand','rrange','randInt','pg',
]);
const TYPES=`
interface Huc6280CodeState {
  clock:number;initialized:boolean;selectedChannel:number;globals:number[];
  registers:number[][];waveforms:number[][];indices:number[];positionFrames:number;
  editorSource:'wave'|'noise'|'dda';editorLfoEnabled:boolean;editorLfoMode:'follow'|'recorded';
  dda:{samples:number;sampleRate:number;rootNote:number;loop:boolean;speed:number};
  ddaVoices:Array<{channel:PlaygroundHuc6280Channel;position:number;ended:boolean;sampleRate:number;rootNote:number;loop:boolean;speed:number}|null>;
  envelopes:Array<{enabled:boolean;attack:number;decay:number;sustain:number;release:number}|null>;
  observation:{registers:'sent';waveforms:'configured';softwareEnvelope:true};
}
/** Serializable hardware operations; no software ADSR, PCM upload or callbacks at playback time. */
type Huc6280TimedMethod='writeRegister'|'setVolume'|'setPan'|'setMasterVolume'|'setFrequency'|'setNote'|'keyOn'|'keyOff'|'allNotesOff'|'setNoise'|'setDda'|'writeDda'|'setLfo';
type Huc6280TimedRecorder={
  [K in Huc6280TimedMethod]:(...args:Parameters<PlaygroundHuc6280[K]>)=>Huc6280TimedRecorder;
} & {atSeconds(offset:number):Huc6280TimedRecorder;atSample(offset:number):Huc6280TimedRecorder};
type Huc6280Operations={version:1;chip:'huc6280';referenceSampleRate:number;operations:Array<{time:{unit:'seconds'|'sample';value:number};order:number;method:string;args:unknown[]}>};
type Huc6280OperationState={clock:number;initialized:boolean;selectedChannel:number;globals:number[];registers:number[][];waveforms:number[][];indices:number[]};
/** Detached sent-register/control state; not oscillator phase or a native save-state. */
type Huc6280TimedSnapshot={readonly format:'tetorica-huc6280-state';readonly version:1;readonly instanceId:string|number;readonly frame:number;readonly sampleRate:number;readonly state:Huc6280OperationState};
type Huc6280TimedWrite={offsetSeconds:number;register:number;value:number;operationIndex:number;writeIndex:number};
type Huc6280Reservation={name:string;sampleRate:number;startFrame?:number;entries:number;repeatSeconds?:number;staged?:boolean};
/** The editor's one physical HuC6280. Await commands. CH5/CH6 support Noise;
 * shared hardware LFO uses CH2 to modulate CH1. Scheduling/FX are software. */
type Huc6280CodeClient=Omit<PlaygroundHuc6280,'dispose'|'noteOn'|'noteOff'|'keyOff'|'build'|'compile'|'schedule'|'clearSchedule'|'captureState'> & {
  readonly id:string;readonly chip:'huc6280';readonly channels:6;readonly clock:number;
  /** Record raw hardware calls once without changing the chip. Times are absolute offsets; sample reference defaults to 44100 Hz. Use setNote + keyOn/keyOff instead of software-envelope noteOn/off. */
  build<Result>(callback:(builder:Huc6280TimedRecorder)=>Result & (Result extends PromiseLike<unknown>?never:unknown),options?:{referenceSampleRate?:number}):Huc6280Operations;
  /** Apply in AudioWorklet at sample boundaries. Same-name replacement is atomic; repeatSeconds exceeds the last offset. */
  schedule(operations:Huc6280Operations,options:{name:string;repeatSeconds?:number}):Promise<Huc6280Reservation>;
  clearSchedule(name:string):Promise<boolean>;
  captureState():Promise<Huc6280TimedSnapshot>;
  /** Current uses an acknowledged Worklet snapshot. Reset/reused snapshots need no state RPC. Client rejects: this Synth has no complete local register mirror. */
  compile(operations:Huc6280Operations,options?:{initialState?:'current'|'reset'|'client'|Huc6280TimedSnapshot}):Promise<Huc6280TimedWrite[]>;
  /** Detached sent-register state, not live hardware oscillator readback. */
  getState():Promise<Huc6280CodeState>;
  /** Start the current waveform or loaded DDA sample with the authored Software Envelope. */
  noteOn(channel:PlaygroundHuc6280Channel,note:string|number):Promise<{channel:PlaygroundHuc6280Channel;stolenId:string|null}>;
  /** Software envelope release of this Code-owned note. keyOff is a raw gate. */
  noteOff(channel:PlaygroundHuc6280Channel):Promise<boolean>;
  /** Raw gate. Returns false when a keyboard voice owns this channel. */
  keyOff(channel:PlaygroundHuc6280Channel):Promise<boolean>;
  /** Restore the authored instrument without closing its AudioContext. */
  dispose():Promise<unknown>;
};
type Huc6280CodeMsm5205LoadOptions={rate?:PlaygroundMsm5205Rate;signal?:AbortSignal;name?:string;path?:string};
type Huc6280CodeMsm5205=Omit<PlaygroundMsm5205API,'loadMemory'|'loadSample'> & {
  readonly id:string;readonly chip:'msm5205';readonly sourceId:string;
  loadMemory(source:ArrayBuffer|Uint8Array|Blob|string,options?:Huc6280CodeMsm5205LoadOptions):Promise<Readonly<PlaygroundMsm5205Sample>>;
  loadSample(source:PlaygroundMsm5205PCM|AudioBuffer|ArrayBuffer|Uint8Array|Blob|string,
    options?:Huc6280CodeMsm5205LoadOptions & {decodeAudio?:(bytes:ArrayBuffer)=>Promise<AudioBuffer|PlaygroundMsm5205PCM>}):Promise<Readonly<PlaygroundMsm5205Sample>>;
  /** Release this Code lease; the UI's authored sample and clock remain. */
  dispose():Promise<void>;
};
type Huc6280CodeCdda=Omit<PlaygroundCddaAPI,'list'> & {
  readonly id:string;readonly chip:'cdda';readonly sourceId:string;
  list():ReadonlyArray<PlaygroundCddaTrack>;
  /** Release this Code lease; the UI's track selection and Synth clock remain. */
  dispose():Promise<void>;
};
type Huc6280CodeSoundChipMap={huc6280:Huc6280CodeClient;msm5205:Huc6280CodeMsm5205;cdda:Huc6280CodeCdda};
type PlaygroundLivePrepareAPI=Huc6280CodeAPI;
declare function useSoundChip<Name extends keyof Huc6280CodeSoundChipMap>(name:Name):Promise<Huc6280CodeSoundChipMap[Name]>;
declare function trackAsync(task:PromiseLike<unknown>):void;
declare function parseNoteName(note:string):number;
declare function midiToNoteName(midi:number):string;
declare const pg:Huc6280CodeAPI;
`;
export function selectHuc6280CodeDeclarations(source) {
  return selectCodeHostDeclarations(source,{globals:HUC6280_CODE_GLOBALS,customTypes:TYPES,apiName:'Huc6280CodeAPI',
    banner:'PC Engine CD-ROM² Synth Code: shared HuC6280/MSM5205/CD-DA; no independent clock.',transformTypes(types){
      const type=types.get('PlaygroundHuc6280');if(!type)throw Error('Shared HuC6280 declarations are missing.');
      types.set(type.name,{...type,text:type.text.replace(/^(\s+\w+\([^\n]*\)):\s*void;/gm,'$1: Promise<void>;')
        .replace(/^(\s+\w+\([^\n]*\)):\s*number;/gm,'$1: Promise<number>;')});
      const state=types.get('PlaygroundMsm5205State'),sample=types.get('PlaygroundMsm5205Sample');
      if(!state||!sample)throw Error('Shared MSM5205 declarations are missing.');
      types.set(state.name,{...state,text:state.text.replace("state:'ready'|'playing'|'ended'","state:'empty'|'ready'|'playing'|'ended'")
        .replace(/=\s*\{/,`= {\n  sourceId:string;revision:number;defaults:{rate:PlaygroundMsm5205Rate;loop:boolean};`)});
      types.set(sample.name,{...sample,text:sample.text.replace(/=\s*\{/,`= {\n  name:string;path:string|null;format:'wav'|'adpcm';paddedDuration:number;`)});
      const cdda=types.get('PlaygroundCddaState');if(!cdda)throw Error('Shared CD-DA declarations are missing.');
      types.set(cdda.name,{...cdda,text:cdda.text.replace("state:'ready'|'playing'|'paused'|'ended'","state:'empty'|'ready'|'playing'|'paused'|'ended'")
        .replace(/=\s*\{/,`= {\n  sourceId:string;revision:number;`)});
    }});
}
